const letters = {
  tired: {
    title: "For the tired version of you",
    text: "You don't have to have everything figured out tonight. Rest. Breathe. Eat something. And remember that somewhere, there is a girl who is ridiculously proud of you and would happily sit beside you through the difficult bits."
  },
  miss: {
    title: "For when you miss me",
    text: "I know. I miss you too. Unfortunately, I have no immediate solution except this tiny corner of the internet and the fact that I am probably thinking about you too."
  },
  bad: {
    title: "For a bad day",
    text: "One bad day does not get to rewrite the story. Come back tomorrow. I will still be here. And yes, you are still stuck with me."
  }
};

function startCase(){
  document.getElementById('case').scrollIntoView({behavior:'smooth'});
}
function showEvidence(){
  document.getElementById('evidence').scrollIntoView({behavior:'smooth'});
}
function openLetter(type){
  document.getElementById('modalTitle').textContent=letters[type].title;
  document.getElementById('modalText').textContent=letters[type].text;
  document.getElementById('modal').classList.remove('hidden');
}
function closeModal(){
  document.getElementById('modal').classList.add('hidden');
}
function unlock(){
  const input=document.getElementById('password');
  const msg=document.getElementById('vaultMessage');
  const value=input.value.trim().toLowerCase().replace(/\s/g,'');
  // Change this password if you want. Current password: 1141
  if(value==='1141'){
    msg.textContent='ACCESS GRANTED. You found the last page.';
    msg.style.color='#e9c7b7';
    setTimeout(()=>{
      document.getElementById('final').classList.remove('hidden');
      document.getElementById('final').scrollIntoView({behavior:'smooth'});
    },900);
  }else{
    msg.textContent='ACCESS DENIED. Hint: the time that changed everything.';
    msg.style.color='#9997a0';
  }
}
function restart(){
  window.scrollTo({top:0,behavior:'smooth'});
}
window.addEventListener('load',()=>{
  let p=0;
  const texts=['Locating subject...','Decrypting memories...','Cross-checking evidence...','9:41 PM confirmed.','Access granted.'];
  const timer=setInterval(()=>{
    p+=4;
    document.getElementById('progress').style.width=p+'%';
    document.getElementById('loadingText').textContent=texts[Math.min(Math.floor(p/25),4)];
    if(p>=100){
      clearInterval(timer);
      setTimeout(()=>{
        document.getElementById('loader').classList.add('hidden');
        document.getElementById('site').classList.remove('hidden');
      },400);
    }
  },80);
});

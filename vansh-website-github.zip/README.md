# VANSH // CLASSIFIED

A simple personal surprise website made with plain HTML, CSS and JavaScript.

## Put it on GitHub Pages

1. Create a GitHub repository, e.g. `vansh-website`.
2. Upload `index.html`, `style.css`, and `script.js`.
3. Commit the files.
4. Go to **Settings → Pages**.
5. Under Source choose **Deploy from a branch**.
6. Choose `main` and `/ (root)`.
7. Save.
8. Your site will appear at `https://YOUR-USERNAME.github.io/vansh-website/`.

## Change the secret password

Open `script.js` and find:

if(value==='1141')

Replace `1141` with your own password.

## Add photos later

Create an `images` folder and upload photos. Then add an `<img>` element to `index.html`, for example:

<img src="images/photo1.jpg" alt="Us">

Everything else works without images, so you can launch the surprise first and personalise it later.
